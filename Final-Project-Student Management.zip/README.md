1. Install Node js 18.13.0
2. Install MongoDB compass
3. unzip packages in a folder
4. Open folder in an IDE
5. Open 2 terminal
6. One terminal go inside client folder and another go to server folder
7. both the terminal write npm i
8. Node dependency will install, after installation run "npm start". Both the code will start running