// Import dependencies
const express = require('express');
const session = require('express-session');

// Create an Express app
const app = express();

// Configure EJS as the view engine
app.set('view engine', 'ejs');

// Middleware to parse the request body
app.use(express.urlencoded({ extended: true }));

// Middleware for session management
app.use(
  session({
    secret: '779a3280-2251-11ee-be56-0242ac120002',
    resave: false,
    saveUninitialized: true
  })
);


const preventCaching = (req, res, next) => {
    res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    res.header('Expires', '-1');
    res.header('Pragma', 'no-cache');
    next();
  };


// Routes
app.get('/',(req, res) => {
  res.render('login');
});

app.post('/login', (req, res) => {
  // Simulating a login process
  const { username, password } = req.body;
  if (username === 'admin' && password === 'password') {
    req.session.loggedIn = true;
    res.redirect('/dashboard');
  } else {
    res.redirect('/');
  }
});

// Middleware to check if user is logged in
const checkLoggedIn = (req, res, next) => {
   
    if (req.session.loggedIn) {
      next(); // User is logged in, proceed to the next middleware
    } else {
      res.redirect('/'); // User is not logged in, redirect to login page
    }
  };

  app.get('/dashboard', preventCaching, (req, res) => {
    if (req.session.loggedIn) {
    res.render('dashboard');
  } else {
    res.redirect('/');
  }
  });

  app.get('/logout', (req, res) => {
    req.session.loggedIn = false;
    res.redirect('/');
  });

// Start the server
const port = 3000;
app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});
