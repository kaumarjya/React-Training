const express = require('express');
const path = require('path');
const bodyparser = require("body-parser");
const session = require("express-session");
const { v4: uuidv4 } = require("uuid");
const app = express();
// Start the server
const port = process.env.PORT || 3001;
const router = require('./router');
app.use(bodyparser.json());
app.use(bodyparser.urlencoded({ extended: true }))

app.set('view engine', 'ejs');

app.use(session({
    secret: uuidv4(), //  '1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed'
    resave: false,
    saveUninitialized: true
}));

app.use('/static', express.static(path.join(__dirname, 'public')))
app.use('/assets', express.static(path.join(__dirname, 'public/assets')))


app.listen(port, () => {
  console.log(`Server started on port ${port}`);
});

app.use('/route', router);

app.get('/',(req, res) => {
    res.render('base', { title : "Welcome Login System"});
  });

  